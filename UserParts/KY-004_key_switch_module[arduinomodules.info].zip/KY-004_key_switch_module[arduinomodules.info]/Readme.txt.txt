﻿//
// ARDUINOMODULES.INFO
// KY-004 Key Switch Module
//
// http://arduinomodules.info/ky-004-key-switch-module/
//

File includes:
 |
 |- KY-004 Key Switch Module.fzpz		//Fritzing Custom Part
 |
 |- Readme.txt					//This file 


Disclaimer:

KY-004 Key Switch Module Fritzing Part is created by arduinomodules.info and published under Creative Commons Attribution-ShareAlike 4.0 International license (https://creativecommons.org/licenses/by-sa/4.0/).
You can use it, share it and/or modify it for any purposes as long as you distribute it under the same license and provide appropriate credit.
