﻿//
// ARDUINOMODULES.INFO
// KY-010 Photo Interrupter Module
//
// http://arduinomodules.info/ky-010-photo-interrupter-module/
//

File includes:
 |
 |- KY-010 Photo Interrupter Module.fzpz	//Fritzing Custom Part
 |
 |- Readme.txt					//This file 


Disclaimer:

KY-010 Photo Interrupter Module Fritzing Part is created by arduinomodules.info and published under Creative Commons Attribution-ShareAlike 4.0 International license (https://creativecommons.org/licenses/by-sa/4.0/).
You can use it, share it and/or modify it for any purposes as long as you distribute it under the same license and provide appropriate credit.
