Fritzing Part: WeMos D1 R2
===================================

Fritzing part for the WeMos D1 R2

<https://wemos.cc>

<http://fritzing.org>

#### Breadboard:

![Fritzing Breadboard](https://github.com/mikeipin/Fritzing-Part-WeMos-D1-R2/blob/master/demo/Fade.png)


#### Schematic:

![Fritzing Schematic](https://github.com/mikeipin/Fritzing-Part-WeMos-D1-R2/blob/master/demo/schematic.png)

#### PCB:

![Fritzing PCB](https://github.com/mikeipin/Fritzing-Part-WeMos-D1-R2/blob/master/demo/pcb.png)
